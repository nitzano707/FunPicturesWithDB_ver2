export interface Photo {
  id: number;
  username: string;
  image_url: string;
  description: string;
  created_at: string;
}
